# rock-paper-scissors-x3
3 ways to code Rock Paper Scissors in JavaScript
